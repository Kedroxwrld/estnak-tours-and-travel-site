# Image placeholders

Every photo in this folder is a branded placeholder. To use your own image,
overwrite the matching file with a JPG or WebP of the same name. Keeping the
same filename means you do not need to edit any HTML.

| File | Recommended size | Used on |
| --- | --- | --- |
| hero-serengeti-balloon.jpg | 1280 x 720 px | Home hero |
| style-island.jpg | 1280 x 721 px | Home travel styles + Destinations hero |
| style-safari.jpg | 1280 x 853 px | Home travel styles + Tours hero |
| style-adventure.jpg | 1280 x 853 px | Home travel styles |
| style-city.jpg | 1280 x 853 px | Home travel styles |
| tour-bwindi.jpg | 1280 x 853 px | Tour cards + About |
| tour-serengeti.jpg | 1280 x 912 px | Tour cards |
| tour-zanzibar.jpg | 1280 x 853 px | Tour cards |
| tour-murchison.jpg | 1280 x 854 px | Tour cards |
| tour-dubai.jpg | 1280 x 960 px | Tour cards + Destinations |
| tour-santorini.jpg | 1280 x 853 px | Tour cards + Destinations |
| pkg-capetown.jpg | 1280 x 853 px | Package carousel + Tour cards |
| pkg-bali.jpg | 1280 x 853 px | Package carousel + Tour cards |
| pkg-paris.jpg | 1280 x 853 px | Package carousel + Tour cards |
| pkg-maldives.jpg | 1280 x 853 px | Package carousel + Tour cards |
| pkg-amboseli.jpg | 1280 x 852 px | Package carousel + Tour cards |
| pkg-kyoto.jpg | 1280 x 853 px | Package carousel + Tour cards |
| about-uganda.jpg | 1280 x 853 px | About story + Tour cards |
| dest-italy.jpg | 1280 x 960 px | Destinations + Tour cards |
| about-journey.jpg | 1280 x 959 px | About hero + About story + Tours |
| about-alps.jpg | 1280 x 853 px | About values band |
| banner-assistance.jpg | 1280 x 725 px | Home assistance banner + Tours CTA |
| dest-uganda.jpg | 1280 x 853 px | Destinations + Contact hero |
| dest-tanzania.jpg | 1280 x 853 px | Destinations |
| dest-zanzibar.jpg | 1280 x 853 px | Destinations |
| dest-japan.jpg | 1280 x 853 px | Destinations |

Tips:

- Keep each photo under about 400 KB so pages stay fast.
- Export at roughly 1600 px wide if your source is larger; the site scales images down.
- Keep the same aspect ratio to avoid cropping surprises. The HTML width/height
  attributes match the sizes above.
- Update the alt text in `src/pages/*.html` so it describes your new photo.
  Good alt text helps screen-reader users and search engines.
- The logo files are `logo.svg` (light backgrounds) and `logo-light.svg` (dark
  backgrounds). Replace them with your own SVG or PNG, or update the paths in
  `partials/header.html` and `partials/footer.html`.

Run `powershell -ExecutionPolicy Bypass -File scripts/make-placeholders.ps1`
to regenerate all placeholders.
